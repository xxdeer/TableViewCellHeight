//
//  UIImage+XX_UIImageColor.h
//  testArray
//
//  Created by Minewtech on 2018/9/20.
//  Copyright © 2018年 Minewtech. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (XX_UIImageColor)

- (UIImage *)imageMaskWithColor:(UIColor *)maskColor;

@end

NS_ASSUME_NONNULL_END
