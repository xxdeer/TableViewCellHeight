//
//  TableViewCellModel.h
//  testArray
//
//  Created by Minewtech on 2018/9/21.
//  Copyright © 2018年 Minewtech. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TableViewCellModel : NSObject

@property (assign, nonatomic) NSInteger cellHeight;

@property (nonatomic,copy) NSString *headerImgStr;

@property (copy,nonatomic) NSString *name;

@property (copy,nonatomic) NSString *address;

@property (nonatomic,strong) NSMutableArray *dataAry;

+ (instancetype)sharedInstance;

+ (CGFloat)heightWithModel:(TableViewCellModel *)model;

@end

NS_ASSUME_NONNULL_END
