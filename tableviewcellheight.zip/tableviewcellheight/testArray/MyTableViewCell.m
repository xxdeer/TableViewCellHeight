//
//  MyTableViewCell.m
//  testArray
//
//  Created by Minewtech on 2018/9/21.
//  Copyright © 2018年 Minewtech. All rights reserved.
//

#import "MyTableViewCell.h"
#import <Masonry.h>

@implementation MyTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initViews];
    }
    return self;
}

- (void)initViews {
    _headerImageView = [[UIImageView alloc]init];
    _headerImageView.backgroundColor = [UIColor lightGrayColor];
    [self.contentView addSubview:_headerImageView];
    
    _nameLabel = [[UILabel alloc]init];
    _nameLabel.numberOfLines = 0;
    _nameLabel.font = [UIFont systemFontOfSize:17];
    [self.contentView addSubview:_nameLabel];
    
    _addressLabel = [[UILabel alloc]init];
    _addressLabel.numberOfLines = 0;
    _addressLabel.textColor = [UIColor lightGrayColor];
    _addressLabel.font = [UIFont systemFontOfSize:15];
    [self.contentView addSubview:_addressLabel];
    
    [_headerImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView).offset(20);
        make.top.equalTo(self.contentView).offset(20);
        make.size.mas_equalTo(CGSizeMake(64, 64));
    }];
    
    [_nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_headerImageView.mas_right).offset(10);
        make.right.equalTo(self.contentView).offset(-20);
        make.top.equalTo(self->_headerImageView).offset(5);
    }];
    
    [_addressLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_nameLabel);
        make.right.equalTo(self.contentView).offset(-20);
        make.top.equalTo(self->_nameLabel.mas_bottom).offset(5);
    }];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
