//
//  ViewController.m
//  testArray
//
//  Created by Minewtech on 2018/9/18.
//  Copyright © 2018年 Minewtech. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+XX_UIImageColor.h"
#import "MyTableViewCell.h"
#import "TableViewCellModel.h"
#import <SDWebImage.h>

#define ScreenHeight [UIScreen mainScreen].bounds.size.height
#define ScreenWidth [UIScreen mainScreen].bounds.size.width

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    UITableView *tableV;
    NSMutableArray *dataAry;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    dataAry = [NSMutableArray arrayWithCapacity:10];
    
    
    for (int i = 0; i<10; i++) {
        if (i == 0) {
            TableViewCellModel *model = [[TableViewCellModel alloc]init];
            model.name = @"titleName1";
            model.address = @"广东省深圳市龙华区港之龙科技园i栋";
            model.headerImgStr = @"http://img.hb.aicdn.com/76a3379861c4d0cfe1b5d0baf4383d66eb5b1f5c29d0c-XvzUme_fw658";
            [dataAry addObject:model];
        }
        else if (i == 1) {
            TableViewCellModel *model = [[TableViewCellModel alloc]init];
            model.name = @"titleName2";
            model.address = @"广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋";
            model.headerImgStr = @"http://img.hb.aicdn.com/4d54d6fc1b7b248bd76889ed5ec8f8ed6a413b5b32872-SQeV6P_fw658";
            [dataAry addObject:model];
        }
        else if (i == 2) {
            TableViewCellModel *model = [[TableViewCellModel alloc]init];
            model.name = @"titleName3";
            model.address = @"广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋";
            model.headerImgStr = @"http://img.hb.aicdn.com/4da891c0f7e61436d2074fcf0efc47855687634719fedc-GhIHfL_fw658";
            [dataAry addObject:model];
        }
        else if (i == 3) {
            TableViewCellModel *model = [[TableViewCellModel alloc]init];
            model.name = @"titleName4";
            model.address = @"广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋";
            model.headerImgStr = @"http://img.hb.aicdn.com/3d0a6d943867f21b16c493bc2cf143da936f906e1a0dd8-X9XZa9_fw658";
            [dataAry addObject:model];
        }
        else if (i == 4) {
            TableViewCellModel *model = [[TableViewCellModel alloc]init];
            model.name = @"titleName5";
            model.address = @"广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋";
            model.headerImgStr = @"http://img.hb.aicdn.com/928280f65af528f99883dc85e2709cf1a03cf18b2416b-RIWRoL_fw658";
            [dataAry addObject:model];
        }
        else if (i == 5) {
            TableViewCellModel *model = [[TableViewCellModel alloc]init];
            model.name = @"titleName6";
            model.address = @"广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋";
            model.headerImgStr = @"http://img.hb.aicdn.com/1c352c1bed14dd2298c274056716fa5bcdcf36b0ac645-q97kps_fw658";
            [dataAry addObject:model];
        }
        else if (i == 6) {
            TableViewCellModel *model = [[TableViewCellModel alloc]init];
            model.name = @"titleName7";
            model.address = @"广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋";
            model.headerImgStr = @"http://img.hb.aicdn.com/79577beac3217287f5ea7eea138549884d766d7883e11-WHTlb0_fw658";
            [dataAry addObject:model];
        }
        else if (i == 7) {
            TableViewCellModel *model = [[TableViewCellModel alloc]init];
            model.name = @"titleName8";
            model.address = @"广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋";
            model.headerImgStr = @"http://img.hb.aicdn.com/b0d7069d5ce90dd5892e313d043b422f47a94e3d398e7-Zu99Fu_fw658";
            [dataAry addObject:model];
        }
        else if (i == 8) {
            TableViewCellModel *model = [[TableViewCellModel alloc]init];
            model.name = @"titleName9";
            model.address = @"广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋";
            model.headerImgStr = @"http://img.hb.aicdn.com/793735527d2e8aaf06dbcbe5b3947b209096c353cefba-qHc1Eq_fw658";
            [dataAry addObject:model];
        }
        else if (i == 9) {
            TableViewCellModel *model = [[TableViewCellModel alloc]init];
            model.name = @"titleName10";
            model.address = @"广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋？？广东省深圳市龙华区港之龙科技园i栋";
            model.headerImgStr = @"http://img.hb.aicdn.com/8607fb3293bb3d40a41b4deefea6837e2f83ec9013406-O39d7A_fw658";
            [dataAry addObject:model];
        }

        
    }
    
    NSLog(@"dataAry : %@",dataAry);
    tableV = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight) style:UITableViewStyleGrouped];
    tableV.tableHeaderView.backgroundColor = [UIColor whiteColor];
    tableV.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    tableV.delegate = self;
    tableV.dataSource = self;
//    tableV.estimatedSectionHeaderHeight = 0;//iOS 11 开始官方API会自动计算高度
//    tableV.estimatedSectionFooterHeight = 0;
    [self.view addSubview:tableV];
    // Do any additional setup after loading the view, typically from a nib.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dataAry.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TableViewCellModel *model = dataAry[indexPath.row];
    NSLog(@"model --- > %@ || %@",model.name,model.address);
    static NSString *identifier = @"MyTableViewCell";
    MyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell)
    {
        cell = [[MyTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    cell.nameLabel.text = model.name;
    cell.addressLabel.text = model.address;
    [cell.headerImageView sd_setImageWithURL:[NSURL URLWithString:model.headerImgStr] placeholderImage:[UIImage imageNamed:@""]];
    
    model.cellHeight = [TableViewCellModel heightWithModel:model];
    NSLog(@"cellHeight--->%ld",(long)model.cellHeight);
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"index--->row:%ld  index--->section:%ld",indexPath.row,indexPath.section);
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TableViewCellModel *model = dataAry[indexPath.row];
    return model.cellHeight ?: UITableViewAutomaticDimension;
}


@end
