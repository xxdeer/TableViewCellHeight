//
//  MyTableViewCell.h
//  testArray
//
//  Created by Minewtech on 2018/9/21.
//  Copyright © 2018年 Minewtech. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyTableViewCell : UITableViewCell
// 门店
@property (nonatomic, strong) UIImageView *headerImageView;
// 门店名
@property (nonatomic, strong) UILabel *nameLabel;
// 门店地址
@property (nonatomic, strong) UILabel *addressLabel;

@end

NS_ASSUME_NONNULL_END
