//
//  XXArray.m
//  testArray
//
//  Created by Minewtech on 2018/9/18.
//  Copyright © 2018年 Minewtech. All rights reserved.
//

#import "XXArray.h"

@implementation XXArray

//- (NSArray *)arrayByAddingObject:(id)anObject {
//    [super arrayByAddingObject:anObject];
//    self = [self arrayByAddingObject:anObject];
//    return self;
//}

@end
