//
//  TableViewCellHeightModel.m
//  testArray
//
//  Created by Minewtech on 2018/9/21.
//  Copyright © 2018年 Minewtech. All rights reserved.
//

#import "TableViewCellModel.h"

#define ScreenHeight [UIScreen mainScreen].bounds.size.height
#define ScreenWidth [UIScreen mainScreen].bounds.size.width

@implementation TableViewCellModel

+ (instancetype)sharedInstance {
    
    static TableViewCellModel *model = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        model = [[self alloc]init];
    });
    return model;
}

- (instancetype)init{
    self = [super init];
    
    if (self) {
        _dataAry = [[NSMutableArray alloc]init];
    }
    return self;
}

/** 计算cell高度 */
+ (CGFloat)heightWithModel:(TableViewCellModel *)model {
    //SimpleFrameModel *model = self.dataArray[indexPath.row];
    NSString *string = model.address;
    
    NSMutableAttributedString *attrStr = [[NSMutableAttributedString alloc] initWithString:string];
    
    NSRange allRange = [string rangeOfString:string];
    
    [attrStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:15.0] range:allRange];
    
    [attrStr addAttribute:NSForegroundColorAttributeName value:[UIColor darkGrayColor]range:allRange];
    
    CGFloat titleHeight;
    
    NSStringDrawingOptions options =  NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading;
    
    // 获取label的最大宽度
    CGRect rect = [attrStr boundingRectWithSize:CGSizeMake(ScreenWidth-114, CGFLOAT_MAX)options:options context:nil];
    
    titleHeight = ceilf(rect.size.height);
    
    return titleHeight + 83; // 动态高度 + 静态高度
}


@end
